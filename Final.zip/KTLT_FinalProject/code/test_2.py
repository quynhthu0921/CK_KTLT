from pymongo import MongoClient
import random
import json
import os

def update_showtimes_with_random_seats():
    """Fetch all showtimes, assign random seats, and save to JSON."""
    try:
        # Connect to MongoDB
        client = MongoClient("mongodb://localhost:27017/")
        db = client["data"]

        # Fetch all showtimes
        all_showtimes = list(db["showtimes_lst"].find({}))
        if not all_showtimes:
            print("❌ No showtimes found in the database!")
            return

        # Define seat options
        rows = ["A", "B", "C", "D", "E", "F", "G", "H"]
        seats = [f"{row}{col}" for row in rows for col in range(1, 9)]  # A1 - H8

        updated_showtimes = []
        for showtime in all_showtimes:
            # Randomly select 5–15 seats
            selected_chairs = random.sample(seats, k=random.randint(5, 15))
            showtime["chair"] = selected_chairs

            # Convert ObjectId to string for JSON serialization
            showtime["_id"] = str(showtime["_id"])
            updated_showtimes.append(showtime)

        # Update MongoDB entries
        modified_count = 0
        for showtime in updated_showtimes:
            result = db["showtimes_lst"].update_one(
                {"_id": showtime["_id"]},  # Match by unique ID
                {"$set": {"chair": showtime["chair"]}}
            )
            if result.modified_count > 0:
                modified_count += 1

        print(f"✅ Successfully updated {modified_count}/{len(updated_showtimes)} showtimes with random seats!")

        # Create directory if not existing
        os.makedirs("data", exist_ok=True)

        # Save results to a JSON file
        output_file = "data/test.json"
        with open(output_file, "w", encoding="utf-8") as file:
            json.dump(updated_showtimes, file, ensure_ascii=False, indent=4)

        print(f"📁 Updated showtimes saved to '{output_file}'!")

    except Exception as e:
        print(f"❌ Error: {e}")

# Run the script
update_showtimes_with_random_seats()
