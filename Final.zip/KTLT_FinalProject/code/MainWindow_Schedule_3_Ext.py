import sys
import random
from datetime import datetime, timedelta
from PyQt6.QtWidgets import QApplication, QMainWindow, QMessageBox, QAbstractItemView
from PyQt6.QtCore import QStringListModel
from PyQt6.uic import loadUi
from pymongo import MongoClient
import json
import os

# Kết nối MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["data"]
theater_collection = db["theater_lst"]
movie_collection = db["movie_lst"]
showtime_collection = db["showtimes_lst"]

class ScheduleWindow3(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("MainWindow_Schedule_3.ui", self)

        # Kết nối các nút

        self.Back.clicked.connect(self.go_back_to_schedule_2)

        # Load dữ liệu vào ListViews
        self.load_data()

        # Cho phép chọn nhiều mục
        self.Theater.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)
        self.Movie.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)

    def load_data(self):
        """Load rạp chiếu và phim từ MongoDB."""
        try:
            theaters = list(theater_collection.find({"status": "Hoạt động"}))
            movies = list(movie_collection.find({"status": "On-air"}))

            self.theaterList = [t.get("id", "UNKNOWN") for t in theaters]
            self.movieList = [m.get("movie_id", "UNKNOWN") for m in movies]

            self.Theater.setModel(QStringListModel(self.theaterList))
            self.Movie.setModel(QStringListModel(self.movieList))
        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Failed to load data from MongoDB:\n{e}")

    def get_selected_items(self, listview):
        """Lấy các mục đã chọn từ một ListView."""
        return [index.data() for index in listview.selectedIndexes()]

    def generate_random_times(self, start_time, end_time, show_count, movie_duration=150):
        """Tạo các suất chiếu ngẫu nhiên trong một khoảng thời gian."""
        valid_times = []
        total_minutes = (end_time - start_time).total_seconds() // 60

        if total_minutes < movie_duration:
            return []  # Không đủ thời gian

        while len(valid_times) < show_count:
            random_offset = random.randint(0, int(total_minutes - movie_duration))
            random_time = start_time + timedelta(minutes=random_offset)
            rounded_minutes = (random_time.minute // 10) * 10
            rounded_time = random_time.replace(minute=rounded_minutes, second=0, microsecond=0)

            if all(abs(rounded_time - datetime.strptime(existing_time, "%H:%M")) >= timedelta(minutes=movie_duration)
                   for existing_time in valid_times):
                valid_times.append(rounded_time.strftime("%H:%M"))

        return sorted(valid_times)


    def go_back_to_schedule_2(self):
        """Go back to ScheduleWindow2."""
        try:
            from MainWindow_Schedule_2_Ext import ScheduleWindow2
            self.schedule_window2 = ScheduleWindow2(self)
            self.schedule_window2.show()
            self.hide()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to go back: {e}")

    def clear_form(self):
        """Clear input fields while keeping Movie and Theater selections."""
        self.Time.clear()
        self.Date.clear()
        self.Show.clear()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ScheduleWindow3()
    window.show()
    sys.exit(app.exec())
