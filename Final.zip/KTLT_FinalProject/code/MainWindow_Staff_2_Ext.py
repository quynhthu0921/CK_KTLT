from PyQt6.QtWidgets import QMainWindow, QMessageBox, QButtonGroup
from PyQt6.uic import loadUi
from pymongo import MongoClient


class StaffWindow2(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("MainWindow_Staff_2.ui", self)  # Load giao diện từ file .ui
        self.parent_window = parent  # Lưu cửa sổ cha

        # Nhóm các radio button để đảm bảo chỉ chọn một trạng thái
        self.status_group = QButtonGroup(self)
        self.status_group.addButton(self.On)
        self.status_group.addButton(self.Off)
        self.status_group.addButton(self.Quit)

        # Kết nối MongoDB
        self.collection = self.connect_mongo()

        # Gán sự kiện cho nút
        self.Back.clicked.connect(self.return_to_staff1)
        self.Save.clicked.connect(self.save_staff)
        self.Update.clicked.connect(self.update_staff)

        # Khi nhập ID nhân viên, tự động hiển thị thông tin nếu có
        self.ID.textChanged.connect(self.load_existing_staff)

    @staticmethod
    def connect_mongo():
        """Kết nối MongoDB"""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]  # Database name
            return db["staff_lst"]  # Collection name
        except Exception as e:
            QMessageBox.critical(None, "Lỗi", f"Lỗi kết nối MongoDB:\n{e}")
            return None

    def load_existing_staff(self):
        """Tự động hiển thị thông tin nếu nhân viên đã tồn tại"""
        staff_id = self.ID.text().strip()
        if not staff_id:
            return

        staff = self.collection.find_one({"employee_id": staff_id})

        if staff:
            self.Name.setText(staff.get("name", ""))
            self.Position.setText(staff.get("position", ""))
            self.Salary.setText(str(staff.get("salary", "")))
            self.set_status(staff.get("status"))
        else:
            self.clear_fields()

    def save_staff(self):
        """Thêm nhân viên mới vào MongoDB"""
        staff_data = self.get_staff_data()
        if not staff_data:
            return

        if self.collection.find_one({"employee_id": staff_data["employee_id"]}):
            QMessageBox.warning(self, "Lỗi", "ID nhân viên đã tồn tại! Hãy dùng chức năng Sửa hoặc kiểm tra lại ID!")
            return

        self.collection.insert_one(staff_data)
        QMessageBox.information(self, "Thông báo", "Nhân viên đã được thêm!")
        self.return_to_staff1()

    def update_staff(self):
        """Cập nhật thông tin nhân viên"""
        staff_data = self.get_staff_data()
        if not staff_data:
            return

        result = self.collection.update_one({"employee_id": staff_data["employee_id"]}, {"$set": staff_data})

        if result.matched_count:
            QMessageBox.information(self, "Thông báo", "Cập nhật nhân viên thành công!")
            self.return_to_staff1()
        else:
            QMessageBox.warning(self, "Lỗi", "Nhân viên không tồn tại! Hãy thêm mới.")

    def get_staff_data(self):
        """Lấy dữ liệu từ form"""
        staff_id = self.ID.text().strip()
        name = self.Name.text().strip()
        position = self.Position.text().strip()
        salary = self.Salary.text().strip()
        status = self.get_status()

        if not staff_id or not name or not position or not salary:
            QMessageBox.warning(self, "Lỗi", "Vui lòng nhập đầy đủ thông tin!")
            return None

        try:
            salary = int(salary)  # Chuyển đổi salary sang kiểu số nguyên
            if salary <= 0:
                QMessageBox.warning(self, "Lỗi", "Lương phải là số nguyên dương!")  # Kiểm tra số nguyên dương
                return None
        except ValueError:
            QMessageBox.warning(self, "Lỗi", "Lương phải là số!")  # Hiển thị thông báo nếu không phải số
            return None

        return {
            "employee_id": staff_id,
            "name": name,
            "position": position,
            "salary": salary,
            "status": status
        }

    def set_status(self, status):
        """Thiết lập trạng thái từ database lên UI"""
        self.On.setChecked(status == "Đang làm")
        self.Off.setChecked(status == "Tạm nghỉ")
        self.Quit.setChecked(status == "Đã nghỉ")

    def get_status(self):
        """Lấy trạng thái từ UI"""
        if self.On.isChecked():
            return "Đang làm"
        elif self.Off.isChecked():
            return "Tạm nghỉ"
        elif self.Quit.isChecked():
            return "Đã nghỉ"
        return ""

    def clear_fields(self):
        """Xóa dữ liệu trên form"""
        self.Name.clear()
        self.Position.clear()
        self.Salary.clear()
        self.set_status("")

    def return_to_staff1(self):
        """Quay về cửa sổ chính"""
        if self.parent_window:
            self.parent_window.show()
            self.parent_window.load_staff_data()
        self.close()