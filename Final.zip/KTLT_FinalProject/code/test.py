import random
from datetime import datetime, timedelta
import json  # Dùng thư viện JSON để xuất dữ liệu

# Danh sách rạp và số phòng tương ứng
theaters = {
    "R001": 5,
    "R002": 5,
    "R003": 5,
    "R004": 5,
    "R005": 5,
    "R006": 4,
}

# Danh sách phim
movies = [f"MV{i:03d}" for i in range(1, 9)]  # MV001 đến MV008

# Ngày chiếu (7 ngày đầu tháng 4 năm 2025)
start_date = datetime(2025, 4, 1)
dates = [(start_date + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]

# Giờ chiếu (từ 10:00 đến 22:00)
times = [f"{hour:02d}:{minute:02d}" for hour in range(10, 23) for minute in [0, 10, 20, 30, 40, 50]]

# Hàm tạo dữ liệu suất chiếu
def generate_showtimes(num_showtimes=500):
    showtimes = []
    for _ in range(num_showtimes):
        while True:  # Lặp đến khi tìm được suất chiếu hợp lệ
            # Chọn ngẫu nhiên rạp và phòng chiếu
            cinema_id = random.choice(list(theaters.keys()))
            max_rooms = theaters[cinema_id]
            room_id = random.randint(1, max_rooms)

            # Chọn ngẫu nhiên phim, ngày và giờ
            movie_id = random.choice(movies)
            date = random.choice(dates)
            time = random.choice(times)
            new_datetime = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M")

            # Kiểm tra khoảng cách thời gian với các suất chiếu đã có
            conflict = False
            for showtime in showtimes:
                if (showtime["cinema_id"] == cinema_id and
                        showtime["room_id"] == str(room_id) and
                        showtime["date"] == date):
                    existing_datetime = datetime.strptime(f"{showtime['date']} {showtime['time']}", "%Y-%m-%d %H:%M")
                    time_difference = abs((new_datetime - existing_datetime).total_seconds() / 60)  # Tính phút
                    if time_difference < 150:  # Ít hơn 150 phút
                        conflict = True
                        break
            if not conflict:
                # Tạo dữ liệu suất chiếu (Gán showtime_id sau khi hợp lệ)
                showtimes.append({
                    "showtime_id": "",  # Để trống để gán ID sau
                    "cinema_id": cinema_id,
                    "room_id": str(room_id),
                    "movie_id": movie_id,
                    "date": date,
                    "time": time
                })
                break  # Thoát vòng lặp khi suất chiếu hợp lệ

    # Sắp xếp các suất chiếu theo thứ tự thời gian
    showtimes.sort(key=lambda x: datetime.strptime(f"{x['date']} {x['time']}", "%Y-%m-%d %H:%M"))

    # Gán ID theo thứ tự thời gian
    for i, showtime in enumerate(showtimes, start=1):
        showtime["showtime_id"] = f"ST{i:03d}"

    return showtimes

# Tạo 1000 dòng dữ liệu suất chiếu
data = generate_showtimes(500)

# In ra dữ liệu dưới dạng JSON để dễ đọc
print(json.dumps(data, indent=4, ensure_ascii=False))