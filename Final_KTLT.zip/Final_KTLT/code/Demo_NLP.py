import json
import matplotlib.pyplot as plt
from collections import Counter
from nltk.sentiment import SentimentIntensityAnalyzer
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext

# Initialize SentimentIntensityAnalyzer
sia = SentimentIntensityAnalyzer()

def classify_sentiment(comment):
    """
    Classify the sentiment of a comment with adjusted thresholds.
    """
    score = sia.polarity_scores(comment)
    if score['compound'] >= 0.4:  # Adjusted threshold for Positive
        return "Positive"
    elif score['compound'] <= -0.4:  # Adjusted threshold for Negative
        return "Negative"
    else:
        return "Neutral"

def analyze_sentiments(file_path):
    """
    Analyze sentiments from a JSON file.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)

        # Validate JSON structure
        if "reviews" not in data or not isinstance(data["reviews"], list):
            raise ValueError("Invalid JSON format. Expected a 'reviews' list.")

        sentiments = {"Positive": [], "Neutral": [], "Negative": []}

        # Classify sentiments for each comment
        for entry in data["reviews"]:
            if "comment" in entry:
                sentiment = classify_sentiment(entry["comment"])
                sentiments[sentiment].append(entry["comment"])

        # Calculate sentiment counts
        sentiment_counts = {sent: len(comments) for sent, comments in sentiments.items()}
        total_comments = sum(sentiment_counts.values())

        # Display sentiment proportions
        result = "Sentiment Analysis Results:\n"
        for sentiment, count in sentiment_counts.items():
            proportion = (count / total_comments) * 100 if total_comments > 0 else 0
            result += f"{sentiment}: {proportion:.2f}%\n"

        messagebox.showinfo("Analysis Results", result)

        # Display comments by sentiment category in a new window
        detail_window = tk.Toplevel(root)
        detail_window.title("Sentiment Details")
        detail_window.geometry("800x600")  # Enlarged window for better readability

        text_area = scrolledtext.ScrolledText(detail_window, wrap=tk.WORD, width=100, height=30)  # Enlarged area
        text_area.pack(pady=10)

        for sentiment, comments in sentiments.items():
            text_area.insert(tk.END, f"{sentiment} Comments:\n")
            for comment in comments:
                text_area.insert(tk.END, f"- {comment}\n")
            text_area.insert(tk.END, "\n")

        text_area.config(state=tk.DISABLED)

        # Create and display pie chart for sentiment distribution
        labels = list(sentiment_counts.keys())
        sizes = list(sentiment_counts.values())
        colors = {"Positive": "green", "Neutral": "blue", "Negative": "red"}
        plt.figure(figsize=(8, 8))  # Enlarged chart for better visibility
        plt.pie(sizes, labels=labels, autopct='%1.1f%%', colors=[colors[label] for label in labels], startangle=140)
        plt.title("Sentiment Distribution")
        plt.show()

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

def open_file():
    """
    Open a file and perform sentiment analysis.
    """
    file_path = filedialog.askopenfilename(
        title="Select JSON File",
        filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
    )
    if file_path:
        analyze_sentiments(file_path)

# GUI Setup
root = tk.Tk()
root.title("Sentiment Analysis Tool")
root.geometry("600x400")

label = tk.Label(root, text="Sentiment Analysis Tool", font=("Arial", 16), fg="blue")
label.pack(pady=20)

button = tk.Button(root, text="Select JSON File", command=open_file, font=("Arial", 14), bg="lightgray")
button.pack(pady=10)

exit_button = tk.Button(root, text="Exit", command=root.destroy, font=("Arial", 14), bg="red", fg="white")
exit_button.pack(pady=10)

root.mainloop()