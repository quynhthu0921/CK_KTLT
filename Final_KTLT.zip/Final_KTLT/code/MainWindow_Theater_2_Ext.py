from PyQt6.QtWidgets import QMainWindow, QMessageBox, QButtonGroup
from PyQt6.uic import loadUi
from pymongo import MongoClient


class TheaterWindow2(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("MainWindow_Theater_2.ui", self)  # Load giao diện từ file .ui
        self.parent_window = parent  # Lưu cửa sổ cha

        # Kết nối MongoDB
        self.collection = self.connect_mongo()

        # Gán sự kiện cho nút
        self.Back.clicked.connect(self.return_to_theater1)
        self.Save.clicked.connect(self.save_theater)
        self.Update.clicked.connect(self.update_theater)

        # Khi nhập ID rạp, tự động hiển thị thông tin nếu có
        self.ID.textChanged.connect(self.load_existing_theater)

        # Nhóm radio button lại để đảm bảo chỉ chọn 1 trạng thái
        self.status_group = QButtonGroup(self)
        self.status_group.addButton(self.On)
        self.status_group.addButton(self.Off)
        self.status_group.addButton(self.Quit)

    @staticmethod
    def connect_mongo():
        """Kết nối MongoDB"""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]  # Database name
            return db["theater_lst"]  # Collection name
        except Exception as e:
            QMessageBox.critical(None, "Lỗi", f"Lỗi kết nối MongoDB:\n{e}")
            return None

    def load_existing_theater(self):
        """Tự động hiển thị thông tin nếu rạp đã tồn tại"""
        theater_id = self.ID.text().strip()
        if not theater_id:
            return

        theater = self.collection.find_one({"id": theater_id})

        if theater:
            self.Name.setText(theater.get("name", ""))
            self.Address.setText(theater.get("address", ""))
            self.Contact.setText(theater.get("contact", ""))
            self.Number.setText(str(theater.get("number_of_rooms", "")))

            # Thiết lập trạng thái
            self.set_status(theater.get("status", "Hoạt động"))

    def save_theater(self):
        """Thêm rạp mới vào MongoDB"""
        try:
            theater_data = self.get_theater_data()
            if not theater_data:
                return

            if self.collection.find_one({"id": theater_data["id"]}):
                QMessageBox.warning(self, "Lỗi", "ID rạp đã tồn tại! Hãy dùng chức năng Sửa hoặc kiểm tra lại ID!")
                return

            self.collection.insert_one(theater_data)
            QMessageBox.information(self, "Thông báo", "Rạp chiếu đã được thêm!")
            self.return_to_theater1()

        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi thêm rạp:\n{e}")

    def update_theater(self):
        """Cập nhật thông tin rạp"""
        try:
            theater_data = self.get_theater_data()
            if not theater_data:
                return

            result = self.collection.update_one({"id": theater_data["id"]}, {"$set": theater_data})

            if result.matched_count:
                QMessageBox.information(self, "Thông báo", "Cập nhật rạp thành công!")
                self.return_to_theater1()
            else:
                QMessageBox.warning(self, "Lỗi", "Rạp không tồn tại! Hãy thêm mới.")

        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi cập nhật rạp:\n{e}")

    def get_theater_data(self):
        """Lấy dữ liệu từ form"""
        theater_id = self.ID.text().strip()
        name = self.Name.text().strip()
        address = self.Address.text().strip()
        contact = self.Contact.text().strip()
        number_of_rooms = self.Number.text().strip()
        status = self.get_status()

        if not theater_id or not name or not address or not contact or not number_of_rooms:
            QMessageBox.warning(self, "Lỗi", "Vui lòng nhập đầy đủ thông tin!")
            return None

        return {
            "id": theater_id,
            "name": name,
            "address": address,
            "contact": contact,
            "number_of_rooms": int(number_of_rooms),
            "status": status
        }

    def set_status(self, status):
        """Thiết lập trạng thái từ database lên UI"""
        self.On.setChecked(status == "Hoạt động")
        self.Off.setChecked(status == "Tạm dừng")
        self.Quit.setChecked(status == "Đóng cửa")

    def get_status(self):
        """Lấy trạng thái từ UI"""
        if self.On.isChecked():
            return "Hoạt động"
        elif self.Off.isChecked():
            return "Tạm dừng"
        elif self.Quit.isChecked():
            return "Đóng cửa"
        return ""

    def clear_fields(self):
        """Xóa dữ liệu trên form"""
        self.Name.clear()
        self.Address.clear()
        self.Contact.clear()
        self.Number.clear()
        self.status_group.setExclusive(False)
        self.On.setChecked(False)
        self.Off.setChecked(False)
        self.Quit.setChecked(False)
        self.status_group.setExclusive(True)

    def return_to_theater1(self):
        """Quay về cửa sổ chính và load lại dữ liệu"""
        if self.parent_window:
            self.parent_window.show()  # Hiển thị TheaterWindow1
            self.parent_window.load_theater_data()  # Cập nhật lại bảng
        self.close()
