from PyQt6.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt6.uic import loadUi
from pymongo import MongoClient
import sys


class MovieWindow2(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("MainWindow_Movie_2.ui", self)  # Load UI
        self.parent_window = parent  # Save reference to parent window

        # Connect MongoDB
        self.collection = self.connect_mongo("movie_lst")
        self.rating_collection = self.connect_mongo("movie_cate")  # Collection for ratings

        # Populate ComboBox with movie categories
        self.populate_rating_combobox()

        # Connect events for buttons
        self.Back.clicked.connect(self.return_to_movie1)
        self.Save.clicked.connect(self.save_movie)
        self.Update.clicked.connect(self.update_movie)

        # Automatically display information when the movie ID changes
        self.ID.textChanged.connect(self.handle_id_change)

        # Ensure only one status can be selected
        self.Onair.clicked.connect(lambda: self.set_status("On-air"))
        self.Tamngung.clicked.connect(lambda: self.set_status("Tạm ngừng"))
        self.Stop.clicked.connect(lambda: self.set_status("Dừng chiếu"))

    @staticmethod
    def connect_mongo(collection_name):
        """Connect to MongoDB."""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]
            return db[collection_name]
        except Exception as e:
            QMessageBox.critical(None, "Lỗi", f"Lỗi kết nối MongoDB:\n{e}")
            return None

    def populate_rating_combobox(self):
        """Fetch movie ratings from the database and populate ComboBox."""
        try:
            self.Rate.clear()  # Clear current items in ComboBox

            # Add an empty item as the first option
            self.Rate.addItem("  ")

            # Fetch all rating documents
            ratings = list(self.rating_collection.find({}, {"_id": 0, "code": 1}))

            # Check if any ratings are available
            if not ratings:
                raise ValueError("Không có phân loại phim nào trong cơ sở dữ liệu!")

            # Populate the ComboBox with only 'code'
            for rating in ratings:
                code = rating.get("code", "Không rõ")
                self.Rate.addItem(code)

        except Exception as e:
            QMessageBox.warning(self, "Lỗi", f"Lỗi khi tải danh sách phân loại phim:\n{e}")

    def handle_id_change(self):
        self.ID.textChanged.disconnect(self.handle_id_change)  # Temporarily disconnect to prevent recursion
        self.load_existing_movie()
        self.ID.textChanged.connect(self.handle_id_change)  # Reconnect event

    def load_existing_movie(self):
        """Load existing movie information based on movie ID."""
        movie_id = self.ID.text().strip()
        if not movie_id:
            return

        try:
            movie = self.collection.find_one({"movie_id": movie_id})
            if movie:
                self.Name.setText(movie.get("name", ""))
                self.Director.setText(movie.get("director", ""))
                self.Actor.setText(movie.get("actor", ""))
                self.Genre.setText(movie.get("genre", ""))
                self.Date.setText(movie.get("date2", ""))
                self.Time.setText(movie.get("time2", ""))
                self.Language.setText(movie.get("language", ""))
                self.set_rate_combobox(movie.get("rated", ""))  # Set selected rate
                self.Detail.setPlainText(movie.get("detail", ""))
                self.set_status(movie.get("status", ""))
            else:
                self.clear_form(keep_id=True)
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi tải dữ liệu phim:\n{e}")

    def set_rate_combobox(self, rate_code):
        """Set the selected item in the rate ComboBox."""
        for index in range(self.Rate.count()):
            if self.Rate.itemText(index).startswith(rate_code):
                self.Rate.setCurrentIndex(index)
                break

    def save_movie(self):
        """Save new movie information."""
        movie_data = {
            "movie_id": self.ID.text().strip(),
            "name": self.Name.text().strip(),
            "director": self.Director.text().strip(),
            "actor": self.Actor.text().strip(),
            "genre": self.Genre.text().strip(),
            "date2": self.Date.text().strip(),
            "time2": self.Time.text().strip(),
            "language": self.Language.text().strip(),
            "rated": self.get_selected_rate(),
            "detail": self.Detail.toPlainText().strip(),
            "status": "On-air" if self.Onair.isChecked() else "Tạm ngừng" if self.Tamngung.isChecked() else "Dừng chiếu"
        }

        # Kiểm tra các trường bắt buộc
        required_fields = [
            "movie_id", "name", "director", "actor", "genre",
            "date2", "time2", "language", "rated", "detail"
        ]
        missing_fields = [field for field in required_fields if not movie_data[field]]

        if missing_fields:
            # Hiển thị thông báo lỗi với các trường còn thiếu
            missing_fields_str = ", ".join(missing_fields)
            QMessageBox.warning(
                self,
                "Cảnh báo",
                f"Vui lòng điền đầy đủ thông tin các trường sau: {missing_fields_str}!"
            )
            return

        # Kiểm tra ID trùng lặp
        if self.collection.find_one({"movie_id": movie_data["movie_id"]}):
            QMessageBox.warning(self, "Lỗi", "Mã phim đã tồn tại!")
            return

        # Lưu thông tin vào cơ sở dữ liệu
        try:
            self.collection.insert_one(movie_data)
            QMessageBox.information(self, "Thành công", "Phim đã được lưu thành công!")
            self.clear_form()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi lưu phim: {e}")

    def update_movie(self):
        """Update existing movie information."""
        movie_id = self.ID.text().strip()
        if not movie_id:
            QMessageBox.warning(self, "Lỗi", "Vui lòng nhập ID phim!")
            return

        movie_data = {
            "name": self.Name.text().strip(),
            "director": self.Director.text().strip(),
            "actor": self.Actor.text().strip(),
            "genre": self.Genre.text().strip(),
            "date2": self.Date.text().strip(),
            "time2": self.Time.text().strip(),
            "language": self.Language.text().strip(),
            "rated": self.get_selected_rate(),
            "detail": self.Detail.toPlainText().strip(),
            "status": "On-air" if self.Onair.isChecked() else "Tạm ngừng" if self.Tamngung.isChecked() else "Dừng chiếu"
        }

        # Kiểm tra các trường bắt buộc
        required_fields = ["name", "director", "actor", "genre", "date2", "time2", "language", "rated", "detail"]
        missing_fields = [field for field in required_fields if not movie_data[field]]

        if missing_fields:
            # Hiển thị thông báo lỗi với các trường còn thiếu
            missing_fields_str = ", ".join(missing_fields)
            QMessageBox.warning(
                self,
                "Cảnh báo",
                f"Vui lòng điền đầy đủ thông tin!"
            )
            return

        try:
            result = self.collection.update_one({"movie_id": movie_id}, {"$set": movie_data})
            if result.modified_count:
                QMessageBox.information(self, "Thành công", "Phim đã được cập nhật thành công!")
            else:
                QMessageBox.warning(self, "Thông tin", "Không có thay đổi nào được thực hiện!")
            self.clear_form()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi cập nhật phim: {e}")

    def get_selected_rate(self):
        """Get the full selected movie rating from ComboBox."""
        selected_item = self.Rate.currentText()  # Lấy chuỗi đầy đủ từ ComboBox
        return selected_item.strip() if selected_item else ""  # Trả về toàn bộ chuỗi

    def clear_form(self, keep_id=False):
        if not keep_id:
            self.ID.clear()
        self.Name.clear()
        self.Director.clear()
        self.Actor.clear()
        self.Genre.clear()
        self.Date.clear()
        self.Time.clear()
        self.Language.clear()
        self.Rate.setCurrentIndex(-1)  # Clear selection in ComboBox
        self.Detail.clear()
        self.set_status("")

    def set_status(self, status):
        self.Onair.setChecked(status == "On-air")
        self.Tamngung.setChecked(status == "Tạm ngừng")
        self.Stop.setChecked(status == "Dừng chiếu")

    def return_to_movie1(self):
        """Return to MovieWindow1."""
        if self.parent_window:
            self.parent_window.show()
            if hasattr(self.parent_window, "load_movie_data"):
                self.parent_window.load_movie_data()
        self.close()


