from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem, QMessageBox
from PyQt6.uic import loadUi
from pymongo import MongoClient

class ScheduleWindow(QMainWindow):
    def __init__(self, home_window=None):
        super().__init__()
        loadUi("MainWindow_Schedule_1.ui", self)
        self.home_window = home_window  # Lưu tham chiếu đến cửa sổ chính (Home)

        # Liên kết các sự kiện cho các nút và ComboBox
        self.Update.clicked.connect(self.open_schedule_2)
        self.Back.clicked.connect(self.go_back_home)
        self.List.clicked.connect(self.filter_results)  # Lọc kết quả theo tiêu chí
        self.Reset.clicked.connect(self.reset_filters)  # Xóa bộ lọc
        self.Theater.currentIndexChanged.connect(self.update_room_combobox)

        # Tải dữ liệu vào giao diện
        self.load_combobox_data()
        self.load_schedule_data()

    def update_room_combobox(self):
        """Cập nhật danh sách phòng chiếu dựa trên rạp đã chọn."""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]

            selected_theater = self.Theater.currentText().strip()
            if not selected_theater or selected_theater == " ":
                self.Room.clear()
                self.Room.addItem(" ")
                self.Room.setEnabled(False)
                return

            # Truy vấn dữ liệu từ MongoDB
            theaters_collection = db["theater_lst"]
            theater = theaters_collection.find_one(
                {"id": selected_theater, "status": "Hoạt động"},
                {"_id": 0, "number_of_rooms": 1}
            )
            max_rooms = theater["number_of_rooms"] if theater else 0

            # Cập nhật danh sách phòng
            self.Room.clear()
            self.Room.addItem(" ")  # Lựa chọn mặc định
            self.Room.addItems([str(room) for room in range(1, max_rooms + 1)])
            self.Room.setEnabled(True)
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi cập nhật danh sách phòng chiếu:\n{e}")

    def load_combobox_data(self):
        """Tải dữ liệu Theater và Movie vào ComboBox từ MongoDB."""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]

            # Tải danh sách Rạp
            theaters_collection = db["theater_lst"]
            theater_list = theaters_collection.find({"status": "Hoạt động"}, {"_id": 0, "id": 1})
            theater_ids = [theater["id"] for theater in theater_list]
            self.Theater.clear()
            self.Theater.addItem(" ")
            self.Theater.addItems(theater_ids)

            # Tải danh sách Phim
            movies_collection = db["movie_lst"]
            movie_list = movies_collection.find({"status": "On-air"}, {"_id": 0, "movie_id": 1})
            movie_ids = [movie["movie_id"] for movie in movie_list]
            self.Movie.clear()
            self.Movie.addItem(" ")
            self.Movie.addItems(movie_ids)
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi tải dữ liệu từ MongoDB:\n{e}")

    def filter_results(self):
        """Lọc danh sách suất chiếu theo tiêu chí đã chọn."""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]

            # Lấy thông tin từ giao diện
            selected_theater = self.Theater.currentText().strip()
            selected_room = self.Room.currentText().strip()
            selected_movie = self.Movie.currentText().strip()
            selected_date = self.Date.text().strip() if self.Date.text().strip() else None

            # Tạo truy vấn
            query = {}
            if selected_theater:
                query["cinema_id"] = selected_theater
            if selected_room.strip().isdigit():
                query["room_id"] = str(selected_room)
            if selected_movie:
                query["movie_id"] = selected_movie
            if selected_date:
                query["date"] = selected_date

            # Truy vấn MongoDB
            showtimes_collection = db["showtimes_lst"]
            results = list(showtimes_collection.find(
                query,
                {"_id": 0, "showtime_id": 1, "cinema_id": 1, "movie_id": 1, "room_id": 1, "date": 1, "time": 1}
            ).sort([("date", 1), ("time", 1)]))  # Sắp xếp theo ngày và giờ

            # Hiển thị kết quả
            if not results:
                self.Tab.setRowCount(0)
                QMessageBox.information(self, "Thông báo", "Không tìm thấy suất chiếu phù hợp.")
            else:
                self.Tab.setRowCount(len(results))
                self.Tab.setColumnCount(6)
                self.Tab.setHorizontalHeaderLabels(["Mã Suất Chiếu", "Mã Rạp", "Phòng Chiếu", "Mã Phim", "Ngày", "Giờ"])

                for row, result in enumerate(results):
                    self.Tab.setItem(row, 0, QTableWidgetItem(str(result["showtime_id"])))
                    self.Tab.setItem(row, 1, QTableWidgetItem(result["cinema_id"]))
                    self.Tab.setItem(row, 2, QTableWidgetItem(str(result["room_id"])))
                    self.Tab.setItem(row, 3, QTableWidgetItem(result["movie_id"]))
                    self.Tab.setItem(row, 4, QTableWidgetItem(result["date"]))
                    self.Tab.setItem(row, 5, QTableWidgetItem(result["time"]))

        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi lọc dữ liệu:\n{e}")

    def reset_filters(self):
        """Xóa tất cả bộ lọc."""
        try:
            self.Theater.setCurrentIndex(0)
            self.Room.clear()
            self.Room.addItem(" ")
            self.Movie.setCurrentIndex(0)
            self.Date.clear()
            self.Tab.setRowCount(0)
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi xóa bộ lọc:\n{e}")

    def load_schedule_data(self):
        """Tải toàn bộ dữ liệu suất chiếu từ MongoDB."""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]

            showtimes_collection = db["showtimes_lst"]
            showtime_list = list(showtimes_collection.find(
                {},
                {"_id": 0, "showtime_id": 1, "cinema_id": 1, "movie_id": 1, "room_id": 1, "date": 1, "time": 1}
            ).sort([("date", 1), ("time", 1)]))

            self.Tab.setRowCount(len(showtime_list))
            self.Tab.setColumnCount(6)
            self.Tab.setHorizontalHeaderLabels(["Mã Suất Chiếu", "Mã Rạp", "Phòng Chiếu", "Mã Phim", "Ngày", "Giờ"])

            for row, showtime in enumerate(showtime_list):
                self.Tab.setItem(row, 0, QTableWidgetItem(str(showtime.get("showtime_id", ""))))
                self.Tab.setItem(row, 1, QTableWidgetItem(showtime.get("cinema_id", "")))
                self.Tab.setItem(row, 2, QTableWidgetItem(str(showtime.get("room_id", ""))))
                self.Tab.setItem(row, 3, QTableWidgetItem(showtime.get("movie_id", "")))
                self.Tab.setItem(row, 4, QTableWidgetItem(showtime.get("date", "")))
                self.Tab.setItem(row, 5, QTableWidgetItem(showtime.get("time", "")))

        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi tải dữ liệu từ MongoDB:\n{e}")

    def open_schedule_2(self):
        """Mở cửa sổ ScheduleWindow2."""
        try:
            from MainWindow_Schedule_2_Ext import ScheduleWindow2
            self.schedule_window2 = ScheduleWindow2(self)
            self.schedule_window2.show()
            self.hide()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi mở cửa sổ ScheduleWindow2:\n{e}")

    def go_back_home(self):
        """Quay về màn hình chính."""
        try:
            if self.home_window:  # Kiểm tra nếu cửa sổ chính tồn tại
                self.home_window.show()  # Hiển thị lại màn hình chính
            self.close()  # Đóng cửa sổ hiện tại
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi quay lại màn hình chính:\n{e}")