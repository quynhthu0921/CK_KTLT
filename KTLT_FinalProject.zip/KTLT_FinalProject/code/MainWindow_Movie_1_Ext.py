from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem, QApplication, QMessageBox, QHeaderView
from PyQt6.uic import loadUi
from pymongo import MongoClient
import sys


class MovieWindow(QMainWindow):
    def __init__(self, home_window=None):
        super().__init__()
        loadUi("MainWindow_Movie_1.ui", self)
        self.home_window = home_window

        # Gán sự kiện cho nút
        self.Update.clicked.connect(self.open_movie_2)
        self.Back.clicked.connect(self.go_back_home)


        self.collection = self.connect_mongo()
        if self.collection is not None:
            self.load_movie_data()

    @staticmethod
    def connect_mongo():
        """Kết nối MongoDB"""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]
            return db["movie_lst"]
        except Exception as e:
            QMessageBox.critical(None, "Lỗi", f"Lỗi kết nối MongoDB:\n{e}")
            return None

    def load_movie_data(self):
        """Tải dữ liệu từ MongoDB và hiển thị lên bảng"""
        if self.collection is None:
            QMessageBox.critical(self, "Lỗi", "Không thể kết nối tới MongoDB!")
            return

        try:
            movies = list(self.collection.find(
                {"status": {"$ne": "Dừng chiếu"}},
                {
                    "_id": 0,
                    "movie_id": 1,
                    "name": 1,
                    "director": 1,
                    "actor": 1,
                    "genre": 1,
                    "date2": 1,
                    "time2": 1,
                    "language": 1,
                    "rated": 1,
                    "detail": 1,
                    "status": 1,
                }
            ))

            if not movies:
                QMessageBox.information(self, "Thông báo", "Không có dữ liệu phim phù hợp.")
                return

            # Cấu hình bảng
            self.Tab.clearContents()
            self.Tab.setRowCount(len(movies))
            self.Tab.setColumnCount(11)  # Đảm bảo bảng có đủ 11 cột
            self.Tab.setHorizontalHeaderLabels([
                "ID Phim", "Tên Phim", "Đạo diễn", "Diễn viên", "Thể loại",
                "Ngày Khởi Chiếu", "Thời lượng", "Ngôn Ngữ", "Phân loại", "Chi tiết", "Trạng Thái"
            ])

            # Tải dữ liệu vào bảng
            for row, movie in enumerate(movies):
                for col, key in enumerate([
                    "movie_id", "name", "director", "actor", "genre",
                    "date2", "time2", "language", "rated", "detail", "status"
                ]):
                    value = movie.get(key, "Không rõ")

                    # Nếu key là 'rated', chỉ lấy giá trị của 'code' từ trường 'rated'
                    if key == "rated":
                        formatted_value = f"{value}"
                    else:
                        formatted_value = value

                    item = QTableWidgetItem(str(formatted_value))
                    self.Tab.setItem(row, col, item)

            # Đặt chiều cao dòng mặc định
            self.Tab.verticalHeader().setDefaultSectionSize(30)
            self.Tab.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
            self.Tab.setWordWrap(False)  # Không bọc dòng

        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi tải dữ liệu:\n{e}")
    def open_movie_2(self):
        try:
            from MainWindow_Movie_2_Ext import MovieWindow2
            self.movie_window2 = MovieWindow2(self)
            self.movie_window2.show()
            self.hide()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi mở cửa sổ Movie 2:\n{e}")

    def go_back_home(self):
        """Quay về màn hình chính"""
        self.close()
        if self.home_window:
            self.home_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MovieWindow()
    window.show()
    sys.exit(app.exec())