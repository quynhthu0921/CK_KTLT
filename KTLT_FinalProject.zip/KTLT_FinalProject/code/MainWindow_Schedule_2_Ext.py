from PyQt6.QtWidgets import QMainWindow, QMessageBox, QApplication
from PyQt6.uic import loadUi
from pymongo import MongoClient
from datetime import datetime, timedelta

class ScheduleWindow2(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("MainWindow_Schedule_2.ui", self)  # Load the UI file
        self.parent_window = parent  # Save reference to parent window

        # MongoDB Connections
        self.collection = self.connect_mongo("showtimes_lst")
        self.theaters_collection = self.connect_mongo("theater_lst")
        self.movies_collection = self.connect_mongo("movie_lst")

        # Button and ComboBox Connections
        self.load_combobox_data()
        self.Theater.currentTextChanged.connect(self.update_rooms)
        self.Add.clicked.connect(self.add_showtime)
        self.Fix.clicked.connect(self.fix_showtime)
        self.Delete.clicked.connect(self.delete_showtime)
        self.Back.clicked.connect(self.return_to_schedule1)
        self.Manage.clicked.connect(self.open_schedule_3)
        self.ID.textChanged.connect(self.load_existing_showtime)

    @staticmethod
    def connect_mongo(collection_name):
        """Connect to MongoDB."""
        try:
            client = MongoClient("mongodb://localhost:27017/")
            db = client["data"]
            return db[collection_name]
        except Exception as e:
            QMessageBox.critical(None, "Lỗi", f"Lỗi kết nối MongoDB:\n{e}")
            return None

    def load_combobox_data(self):
        """Load data into ComboBoxes."""
        try:
            # Load Theaters (only active ones)
            theaters = self.theaters_collection.find({"status": "Hoạt động"})
            self.Theater.clear()
            self.Theater.addItem("")  # Add an empty option
            for theater in theaters:
                self.Theater.addItem(theater["id"])

            # Load Movies (only on-air ones)
            movies = self.movies_collection.find({"status": "On-air"})
            self.Movie.clear()
            self.Movie.addItem("")  # Add an empty option
            for movie in movies:
                self.Movie.addItem(movie["movie_id"])

            # Update rooms based on the initial theater selection
            self.update_rooms()
        except Exception as e:
            QMessageBox.warning(self, "Lỗi", f"Lỗi khi tải dữ liệu vào ComboBox:\n{e}")

    def update_rooms(self):
        """Update rooms based on selected theater."""
        try:
            theater_id = self.Theater.currentText()
            self.Room.clear()
            self.Room.addItem("")  # Empty option
            if not theater_id:
                return

            theater = self.theaters_collection.find_one({"id": theater_id})
            if not theater:
                QMessageBox.warning(self, "Lỗi", "Không tìm thấy thông tin rạp!")
                return

            max_rooms = theater.get("number_of_rooms", 0)
            for room in range(1, max_rooms + 1):
                self.Room.addItem(str(room))
        except Exception as e:
            QMessageBox.warning(self, "Lỗi", f"Lỗi khi cập nhật phòng chiếu:\n{e}")

    def load_existing_showtime(self):
        """Load details of an existing showtime for editing."""
        showtime_id = self.ID.text().strip()
        if not showtime_id:
            return
        try:
            showtime = self.collection.find_one({"showtime_id": showtime_id})
            if showtime:
                self.Movie.setCurrentText(showtime.get("movie_id", ""))
                cinema_id = showtime.get("cinema_id", "")
                self.Theater.setCurrentText(cinema_id)

                # Only update rooms if cinema_id is valid
                if cinema_id:
                    self.update_rooms()

                self.Room.setCurrentText(str(showtime.get("room_id", "")))
                self.Time.setText(showtime.get("time", ""))
                self.Date.setText(showtime.get("date", ""))
        except Exception as e:
            QMessageBox.warning(self, "Lỗi", f"Lỗi khi tải dữ liệu suất chiếu:\n{e}")

    def add_showtime(self):
        """Add a new showtime to MongoDB."""
        try:
            showtime_data = self.get_showtime_data()
            if not showtime_data or not self.validate_showtime_data(showtime_data):
                return
            if self.collection.find_one({"showtime_id": showtime_data["showtime_id"]}):
                QMessageBox.warning(self, "Lỗi", "ID suất chiếu đã tồn tại! Hãy dùng chức năng Sửa hoặc kiểm tra lại ID!")
                return
            self.collection.insert_one(showtime_data)
            QMessageBox.information(self, "Thông báo", "Suất chiếu đã được thêm!")
            self.clear_fields()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi thêm suất chiếu:\n{e}")

    def fix_showtime(self):
        """Update an existing showtime in MongoDB."""
        try:
            showtime_data = self.get_showtime_data()
            if not showtime_data or not self.validate_showtime_data(showtime_data):
                return
            result = self.collection.update_one({"showtime_id": showtime_data["showtime_id"]}, {"$set": showtime_data})
            if result.matched_count:
                QMessageBox.information(self, "Thông báo", "Suất chiếu đã được cập nhật!")
                self.clear_fields()
            else:
                QMessageBox.warning(self, "Lỗi", "Suất chiếu không tồn tại!")
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi cập nhật suất chiếu:\n{e}")

    def delete_showtime(self):
        """Delete a showtime from MongoDB."""
        try:
            showtime_id = self.ID.text().strip()
            if not showtime_id:
                QMessageBox.warning(self, "Lỗi", "Vui lòng nhập ID suất chiếu!")
                return

            reply = QMessageBox.question(
                self,
                "Xác nhận",
                "Bạn có chắc chắn muốn xóa suất chiếu này?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )

            if reply == QMessageBox.StandardButton.Yes:
                result = self.collection.delete_one({"showtime_id": showtime_id})
                if result.deleted_count:
                    QMessageBox.information(self, "Thông báo", "Suất chiếu đã được xóa!")
                    self.clear_fields()
                else:
                    QMessageBox.warning(self, "Lỗi", "Suất chiếu không tồn tại!")
            else:
                return
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi xóa suất chiếu:\n{e}")

    def get_showtime_data(self):
        """Extract showtime data from the form."""
        showtime_id = self.ID.text().strip()
        movie = self.Movie.currentText().strip()
        theater = self.Theater.currentText().strip()
        room = self.Room.currentText().strip()
        time = self.Time.text().strip()
        date = self.Date.text().strip()
        if not (showtime_id and movie and theater and room and time and date):
            QMessageBox.warning(self, "Lỗi", "Vui lòng nhập đầy đủ thông tin!")
            return None
        return {
            "showtime_id": showtime_id,
            "movie_id": movie,
            "cinema_id": theater,
            "room_id": room,
            "time": time,
            "date": date
        }

    def validate_showtime_data(self, showtime_data):
        """Validate showtime constraints, excluding the current showtime."""
        try:
            new_time = datetime.strptime(showtime_data["time"], "%H:%M")
            min_gap = timedelta(hours=2, minutes=30)

            same_room_showtimes = self.collection.find({
                "cinema_id": showtime_data["cinema_id"],
                "room_id": showtime_data["room_id"],
                "date": showtime_data["date"],
                "showtime_id": {"$ne": showtime_data["showtime_id"]}
            })

            for existing_showtime in same_room_showtimes:
                existing_time = datetime.strptime(existing_showtime["time"], "%H:%M")
                if abs(existing_time - new_time) < min_gap:
                    QMessageBox.warning(self, "Lỗi", "Suất chiếu phải cách nhau tối thiểu 2h30.")
                    return False

        except ValueError:
            QMessageBox.warning(self, "Lỗi", "Thời gian không hợp lệ!")
            return False

        return True

    def clear_fields(self):
        """Clear all input fields."""
        self.ID.clear()
        self.Movie.setCurrentIndex(0)
        self.Theater.setCurrentIndex(0)
        self.Room.setCurrentIndex(0)
        self.Time.clear()
        self.Date.clear()





    def return_to_schedule1(self):
        from MainWindow_Schedule_1_Ext import ScheduleWindow
        try:
            self.schedule_window = ScheduleWindow(self)
            self.schedule_window.show()
            self.hide()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi mở cửa sổ ScheduleWindow3:\n{e}")


    def open_schedule_3(self):
        """Open ScheduleWindow3."""
        from MainWindow_Schedule_3_Ext import ScheduleWindow3
        try:
            self.schedule_window3 = ScheduleWindow3(self)
            self.schedule_window3.show()
            self.hide()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Lỗi khi mở cửa sổ ScheduleWindow3:\n{e}")
